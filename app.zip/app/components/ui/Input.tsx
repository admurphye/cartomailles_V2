import { colors } from "@/app/theme/colors";

type InputProps = {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
};

export default function Input({
  value,
  onChange,
  placeholder,
}: InputProps) {
  return (
    <input
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      style={{
        width: "100%",
        padding: "10px 12px",
        borderRadius: "10px",
        border: `1px solid ${colors.border}`,
        background: colors.workspace,
        color: colors.text,
        fontSize: "15px",
        outline: "none",
      }}
    />
  );
}